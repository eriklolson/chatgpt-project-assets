<p align="center">
  <a href="https://opentemplatehub.com">
    <img src="https://raw.githubusercontent.com/open-template-hub/open-template-hub.github.io/master/assets/logo/ui/web-ui-logo.png" alt="Logo" width=200>
  </a>
</p>


<h1 align="center">
Open Template Hub - Company Profile UI Template v5
  <br/>
(outdated packages)
</h1>

Following packages are not updated in the develop branch yet. So, if you want to update outdated packages on your own risk, update the package.json and install dependencies.

| Package | Current | Wanted | Latest | Location |
| --- | --- | --- | --- | --- |
| @angular-devkit/build-angular | 15.2.11 | 15.2.11 | 18.0.7 | node_modules/@angular-devkit/build-angular |
| @angular/animations | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/animations |
| @angular/cdk | 15.2.9 | 15.2.9 | 18.0.6 | node_modules/@angular/cdk |
| @angular/cli | 15.2.11 | 15.2.11 | 18.0.7 | node_modules/@angular/cli |
| @angular/common | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/common |
| @angular/compiler | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/compiler |
| @angular/compiler-cli | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/compiler-cli |
| @angular/core | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/core |
| @angular/forms | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/forms |
| @angular/language-service | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/language-service |
| @angular/localize | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/localize |
| @angular/platform-browser | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/platform-browser |
| @angular/platform-browser-dynamic | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/platform-browser-dynamic |
| @angular/router | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/router |
| @angular/service-worker | 15.2.10 | 15.2.10 | 18.0.6 | node_modules/@angular/service-worker |
| @types/jasmine | 4.6.4 | 4.6.4 | 5.1.4 | node_modules/@types/jasmine |
| @types/node | 18.19.39 | 18.19.39 | 20.14.10 | node_modules/@types/node |
| helmet | 6.2.0 | 6.2.0 | 7.1.0 | node_modules/helmet |
| ics | 2.44.0 | 2.44.0 | 3.7.6 | node_modules/ics |
| jasmine-core | 4.6.1 | 4.6.1 | 5.1.2 | node_modules/jasmine-core |
| jsdom | 21.1.2 | 21.1.2 | 24.1.0 | node_modules/jsdom |
| ngx-markdown | 15.1.2 | 15.1.2 | 18.0.0 | node_modules/ngx-markdown |
| ngx-toastr | 16.2.0 | 16.2.0 | 19.0.0 | node_modules/ngx-toastr |
| simple-icons | 8.15.0 | 8.15.0 | 13.1.0 | node_modules/simple-icons |
| swiper | 8.4.7 | 8.4.7 | 11.1.4 | node_modules/swiper |
| typescript | 4.9.5 | 4.9.5 | 5.5.3 | node_modules/typescript |
| zone.js | 0.12.0 | 0.12.0 | 0.14.7 | node_modules/zone.js |

<table align="right"><tr><td><a href="https://opentemplatehub.com"><img src="https://raw.githubusercontent.com/open-template-hub/open-template-hub.github.io/master/assets/logo/brand-logo.png" width="50px" alt="oth"/></a></td><td><b>Open Template Hub © 2023</b></td></tr></table>

