import { Component } from '@angular/core';

@Component( {
  selector: 'app-color-chart',
  templateUrl: './color-chart.component.html',
  styleUrls: [ './color-chart.component.scss' ]
} )
export class ColorChartComponent {

  constructor() {
    // Intentionally blank
  }
}
