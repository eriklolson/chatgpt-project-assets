export const PROFILE_IMG = './assets/common/profile-img.png';
