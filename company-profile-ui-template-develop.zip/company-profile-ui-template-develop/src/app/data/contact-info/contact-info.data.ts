export const CONTACT_INFO = {
  address: '',
  email: 'info@opentemplatehub.com',
  phone: '',
  map: 'https://goo.gl/maps/qKdzpwkhLKuQsaWv6',
};
