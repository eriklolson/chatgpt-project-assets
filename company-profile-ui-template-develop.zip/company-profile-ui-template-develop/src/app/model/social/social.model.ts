export interface Social {
  linkedIn?: string;
  twitter?: string;
  github?: string;
  mail?: string;
}
