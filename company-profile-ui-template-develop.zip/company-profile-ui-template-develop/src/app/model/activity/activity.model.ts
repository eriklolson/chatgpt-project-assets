export interface Activity {
  type: string;
  date: Date;
  payload: any;
}
