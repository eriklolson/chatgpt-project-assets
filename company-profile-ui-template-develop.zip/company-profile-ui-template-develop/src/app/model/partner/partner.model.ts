export interface Partner {
  src: string,
  name: string,
  website: string,
  badge?: string;
}
