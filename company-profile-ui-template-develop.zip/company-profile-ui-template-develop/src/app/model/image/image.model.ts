export interface Image {
  src: string;
  description: string;
}
