export interface TimeLineItem {
  title: string,
  date: string,
  paragraph?: string,
  img?: string,
  theme?: string,
  footerText?: string
}
