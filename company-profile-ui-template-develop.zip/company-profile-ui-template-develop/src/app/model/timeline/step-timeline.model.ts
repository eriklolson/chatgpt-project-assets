export interface StepTimeLineItem {
  text: string;
  theme?: string;
  level: number;
}
