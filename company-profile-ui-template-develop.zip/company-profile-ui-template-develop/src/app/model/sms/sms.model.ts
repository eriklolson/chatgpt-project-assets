export interface SmsModel {
  tag: string;
}
