export interface MailModel {
  tag: string;
}
