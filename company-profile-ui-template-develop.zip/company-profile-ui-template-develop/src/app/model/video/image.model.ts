export interface Video {
  url: string;
  description: string;
}
