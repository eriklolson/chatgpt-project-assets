export interface AnalyticsModel {
  tag: string;
  id: string;
}
