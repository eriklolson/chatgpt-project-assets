export interface FileStorageModel {
  tag: string;
}
