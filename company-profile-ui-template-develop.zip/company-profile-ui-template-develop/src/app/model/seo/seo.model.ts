export interface SeoMetaData {
  keywords: string[];
  robots: string[];
  title: string;
  description: string;
}
