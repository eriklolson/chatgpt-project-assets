export interface Doc {
  key: string;
  url: string;
  title: string;
  date: string;
  excerpt: string;
  tag: string;
  imgUri: string;
}
