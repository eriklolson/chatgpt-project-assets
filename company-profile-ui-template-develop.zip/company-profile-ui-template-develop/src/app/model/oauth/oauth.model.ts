export interface OauthModel {
  tag: string;
}
