export interface AuthToken {
  accessToken: any;
  refreshToken: any;
}
