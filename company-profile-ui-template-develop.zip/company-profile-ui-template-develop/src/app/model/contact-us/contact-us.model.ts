export interface ContactUsFeatures {
  title: string;
  features: string[];
}
