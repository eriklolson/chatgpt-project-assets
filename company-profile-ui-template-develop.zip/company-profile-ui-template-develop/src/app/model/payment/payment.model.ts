export interface PaymentModel {
  tag: string;
  publishableKey?: string;
  env?: string;
  clientId?: string;
}
