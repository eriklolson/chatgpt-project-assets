module.exports = {
  singleQuote: true,
  bracketSpacing: true,
  bracketSameLine: true
};
